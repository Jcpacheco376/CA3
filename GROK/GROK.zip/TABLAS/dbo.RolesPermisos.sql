CREATE TABLE [dbo].[RolesPermisos] (

[RoleId] int NULL,
[PermisoId] int NULL
) ON [PRIMARY]
