const readline = require('readline');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

// La carpeta donde se guardará el .env y se instalarán dependencias
const API_DIR = path.join(__dirname, 'api-asistencia');

console.log('=========================================');
console.log('   CONFIGURACIÓN DEL SISTEMA ASISTENCIA   ');
console.log('=========================================');
console.log('Por favor, ingresa los datos del servidor del cliente.\n');

const questions = [
    // --- DATOS DE BASE DE DATOS ---
    { key: 'DB_SERVER', q: '1. IP/Nombre Servidor SQL (Enter para localhost): ',def: 'localhost' },
    { key: 'DB_USER', q: '2. Usuario SQL (Enter para sa): ', def: 'sa'},
    { key: 'DB_PASSWORD', q: '3. Contraseña SQL: ' },
    { key: 'DB_DATABASE', q: '4. Nombre de la Base de Datos (Enter para CA): ', def: 'CA' },
    { key: 'DB_PORT', q: '5. Puerto SQL Server (Enter para 1433): ', def: '1433' },
    
    // --- DATOS DEL SERVIDOR WEB ---
    { key: 'API_PORT', q: '6. Puerto para la PÁGINA WEB (Enter para 3001): ', def: '3001' },
    
    // --- SEGURIDAD ---
    { key: 'JWT_SECRET', q: '7. JWT Secret (Enter para auto-generar): ' }
];

const config = {};

const ask = (i) => {
    if (i === questions.length) return finish();
    const { key, q, def } = questions[i];
    
    rl.question(q, (ans) => {
        let val = ans.trim() || def;
        
        // Generar secreto si se deja vacío
        if (key === 'JWT_SECRET' && !val) {
            val = require('crypto').randomBytes(32).toString('hex');
            console.log(`   -> Secreto generado automáticamente.`);
        }
        
        // Validación básica
        if (!val) { 
            console.log('   ❌ Este dato es requerido.'); 
            return ask(i); 
        }
        
        config[key] = val;
        ask(i + 1);
    });
};

const finish = () => {
    rl.close();
    console.log('\n... Guardando configuración ...');

    // Construir el contenido del archivo .env
    // Agregamos variables fijas necesarias para que tu backend no falle
    let envContent = '';
    
    // 1. Variables capturadas
    for (const [key, value] of Object.entries(config)) {
        envContent += `${key}=${value}\n`;
    }

    // 2. Variables Fijas / Defaults para Producción
    envContent += `NODE_ENV=production\n`;
    // Necesaria para que el log diga "http://localhost:3001" en lugar de undefined
    envContent += `LOCAL_IP=localhost\n`; 
    // Permitir acceso local
    envContent += `ALLOWED_ORIGINS=http://localhost:${config.API_PORT}\n`;

    // Escribir el archivo .env
    if (!fs.existsSync(API_DIR)) {
        console.error(`❌ ERROR CRÍTICO: No se encuentra la carpeta "${API_DIR}". Asegúrate de haber descomprimido todo el zip.`);
        process.exit(1);
    }

    fs.writeFileSync(path.join(API_DIR, '.env'), envContent);
    console.log('✅ Archivo .env creado correctamente.');
    
    // 3. Instalar dependencias
    console.log('\n... Instalando librerías del servidor (esto puede tardar unos minutos)...');
    try {
        execSync('npm install --production', { cwd: API_DIR, stdio: 'inherit' });
        
        console.log('\n=========================================');
        console.log('      INSTALACIÓN COMPLETADA CON ÉXITO    ');
        console.log('=========================================');
        console.log('PASOS PARA INICIAR:');
        console.log('1. Entra a la carpeta "api-asistencia"');
        console.log('2. Ejecuta el comando: npm start');
        console.log(`3. Abre el navegador en: http://localhost:${config.API_PORT}`);
        
    } catch (e) {
        console.error('❌ Error instalando dependencias. Verifica tu conexión a internet.');
    }
    
    console.log('\n(Presiona cualquier tecla para salir)');
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', process.exit.bind(process, 0));
};
35432
// Iniciar el cuestionario
ask(0);